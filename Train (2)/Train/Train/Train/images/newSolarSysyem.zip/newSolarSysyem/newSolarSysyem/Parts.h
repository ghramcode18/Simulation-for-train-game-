#pragma once
#include <windows.h>
#include <gl\gl.h>
#include <cmath>
#include "Point.h"

class Parts
{
public:
	void static draw_advanced_monitor(int image);
	void static draw_sofa(int image,int image2);
	void static draw_office_drawer_desk();
	void static draw_office_desk();
	void static draw_office_carriage(int monitor);
	void static table(int image);
	void static draw_game_machine(int image,int game_machine_screan,int game_place);


	void static drawTriangleTexture(Point p,int img,int img2);
	void static drawCircleTexture(Point p,int img,int img2);
	void static drawRoundTableTexture(int img1,int img2);
	void static drawDinningTableTexture(int img1,int img2);
	void static drawCubeTexture_1(Point p,int img,int img2);



	void static drawEatingTableTexture(int img1,int img2);
	void static draw_solid_cube1(int img1,int img4);
	void static draw_solid_cube2(int img1,int img5);
	void static drawChairTexture(int img1,int img2);
	void static drawCubeTexture(Point p,int img,int img2);
	void static drawSetChairTexture(int img1,int img2);
	void static draw_eating_carriageTexture(int img1,int img2,int img4,int img5);


	//////////////////////////////////////
	void static Parts::draw_bed(int texBed);
};